

<head>
  <meta charset="UTF-8">
  <title>Hardware Production</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'><link rel="stylesheet" href="./style.css">


<!-- partial:index.partial.html -->

<body>
	<!-- Main Content -->
	<div class="container-fluid">
		<div class="row main-content bg-success text-center">
			<div class="col-md-4 text-center company__info">
				<span class="company__logo"><h2><span class="fa fa-android"></span></h2></span>
				<h4 class="company_title">Airqo Hardware
				</h4>
			</div>

			<!DOCTYPE html>
			<html>
			<head>
				<title>Login Form</title>
			</head>
			<body>
				<div class="col-md-8 col-xs-12 col-sm-12 login_form">
					<div class="container-fluid">
						<div class="row">
							<h2>Log In</h2>
						</div>
						<div class="row">
							<form control="" class="form-group" action="../pages/index.php" method="POST">
								<div class="row">
									<input type="text" name="username" id="username" class="form__input" placeholder="Username">
								</div>
								<div class="row">
									<input type="password" name="password" id="password" class="form__input" placeholder="Password">
								</div>
								<div class="row">
									<input type="checkbox" name="remember_me" id="remember_me">
									<label for="remember_me">Remember Me!</label>
								</div>
								<div class="row">
									<input type="submit" value="Submit" class="btn">
								</div>
							</form>
						</div>
						<div class="row">
							<p>Don't have an account? <a href="#">Register Here</a></p>
						</div>
					</div>
				</div>
			</body>
			</html>
			

		</div>
	</div>
	<!-- Footer -->
	<div class="container-fluid text-center footer">
		Coded with &hearts; by <a href="https://www.google/bandamarvin">marv</a></p>
	</div>
</body>
<!-- partial -->

</html>


<?php session_start(); ?>
<html>
<head>
	<title>Login</title>
</head>

<body>
<a href="index.php">Home</a> <br />
<?php
include("connection.php");

if(isset($_POST['submit'])) {
	$user = mysqli_real_escape_string($mysqli, $_POST['username']);
	$pass = mysqli_real_escape_string($mysqli, $_POST['password']);

	if($user == "" || $pass == "") {
		echo "Either username or password field is empty.";
		echo "<br/>";
		echo "<a href='login.php'>Go back</a>";
	} else {
		$result = mysqli_query($mysqli, "SELECT * FROM login WHERE username='$user' AND password=md5('$pass')")
					or die("Could not execute the select query.");
		
		$row = mysqli_fetch_assoc($result);
		
		if(is_array($row) && !empty($row)) {
			$validuser = $row['username'];
			$_SESSION['valid'] = $validuser;
			$_SESSION['name'] = $row['name'];
			$_SESSION['id'] = $row['id'];
		} else {
			echo "Invalid username or password.";
			echo "<br/>";
			echo "<a href='login.php'>Go back</a>";
		}

		if(isset($_SESSION['valid'])) {
			header('Location: pages/index.php');			
		}
	}
} else {
?>
	<p><font size="+2">Login</font></p>
	<form name="form1" method="post" action="">
		<table width="75%" border="0">
			<tr> 
				<td width="10%">Username</td>
				<td><input type="text" name="username"></td>
			</tr>
			<tr> 
				<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr> 
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>
	</form>
<?php
}
?>
</body>
</html>
