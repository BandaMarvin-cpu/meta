

<?php

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Log an example error
trigger_error('This is an example error', E_USER_ERROR);

// Output errors as JavaScript console messages
$errors = error_get_last();
if ($errors !== null) {
    echo '<script>console.error("' . $errors['message'] . '");</script>';
}
?>


// Database configuration
$host = "localhost";
$username = "root";
$password = "6C7VpCjhDDb8";
//$password = "";
$database = "airqo";

// Establish the database connection
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Other configuration variables
$siteName = "Your Web App";
$adminEmail = "admin@example.com";
?>




