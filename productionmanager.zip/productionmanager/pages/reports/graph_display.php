<!DOCTYPE html>
<html>
<head>
    <title>Graph Display</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <button onclick="fetchTableData('predeployment')">Pre-Deployment Analysis</button>
    <button onclick="fetchTableData('printing')">3D Printing</button>
    <button onclick="fetchTableData('monitorassembly')">Monitor Assembly</button>

    <canvas id="barChart"></canvas>

    <script>
        function fetchTableData(type) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_data.php?type=' + type, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    generateGraph(data);
                }
            };
            xhr.send();
        }

        function generateGraph(data) {
            var labels = [];
            var quantities = [];

            // Extract the relevant data from the response
            for (var i = 0; i < data.length; i++) {
                labels.push(data[i].batchno);
                quantities.push(data[i].qty);
            }

            // Create the bar chart
            var ctx = document.getElementById('barChart').getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Quantity',
                        data: quantities,
                        backgroundColor: 'rgba(0, 123, 255, 0.5)',
                        borderColor: 'rgba(0, 123, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Quantity'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Batch'
                            }
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>
