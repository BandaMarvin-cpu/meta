<?php
$type = $_GET['type'];
include 'config.php';

// Check the database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize the data variable
$data = [];

if ($type === 'predeployment') {
    // Fetch data from the "predeploymentanalysis" table in your database
    $table = 'predeploymentanalysis';
} elseif ($type === 'printing') {
    // Fetch data from the "printings" table in your database
    $table = 'printings';
} elseif ($type === 'pcb') {
    // Fetch data from the "pcbassembly" table in your database
    $table = 'pcbassembly';
} elseif ($type === 'monitorassembly') {
    // Fetch data from the "monitorassembly" table in your database
    $table = 'monitorassembly';
}
elseif ($type === 'testing') {
    // Fetch data from the "monitorassembly" table in your database
    $table = 'testing';
}

// Query the table to fetch data
$sql = "SELECT * FROM $table";
$result = mysqli_query($conn, $sql);

// Check if the query executed successfully
if ($result) {
    // Fetch the data from the result set
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);

// Return the data as a JSON response
echo json_encode($data);
?>
