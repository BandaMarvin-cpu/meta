<!DOCTYPE html>
<html>
<head>
    <title>Edit Item</title>
</head>
<body>
    <?php
        // Step 1: Include the config file
        include 'config.php';

        // Step 2: Get the item ID from the query string
        $itemId = $_GET['id'];

        // Step 3: Fetch the item details
        $sql = "SELECT id, item FROM inventory WHERE id='$itemId'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $item = $row['item'];

        // Step 4: Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $newItem = $_POST['item'];

            $sql = "UPDATE inventory SET item='$newItem' WHERE id='$itemId'";
            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    ?>

    <h2>Edit Item</h2>
    <form method="post">
        <input type="text" name="item" value="<?php echo $item; ?>" required>
        <button type="submit">Update</button>
    </form>

    <a href="index.php">Back</a>

    <?php
        // Step 5: Close the database connection
        $conn->close();
    ?>
</body>
</html>
