<?php
// Establish connection to your MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airqo1";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Retrieve and send chat messages
$sql = "SELECT sender, message, timestamp FROM chat_messages ORDER BY timestamp DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $sender = $row['sender'];
    $message = $row['message'];
    $timestamp = $row['timestamp'];
    echo "<p><strong>$sender:</strong> $message</p>";
  }
} else {
  echo "No messages yet.";
}

$conn->close();
?>
