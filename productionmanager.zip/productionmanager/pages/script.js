function getData(type) {
    $.ajax({
      url: 'fetch_data.php',
      type: 'GET',
      data: { type: type },
      success: function(response) {
        // Process the response data and generate the chart
        generateChart(response);
      },
      error: function(xhr, status, error) {
        console.error(xhr.responseText);
      }
    });
  }
  
  function generateChart(data) {
    // Rest of the chart generation code remains the same
  }
  