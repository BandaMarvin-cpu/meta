<?php

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['productionStage'])) {
        $productionStage = $_POST['productionStage'];
    } else {
        // Set a default value if no option is selected
        $productionStage = 1;
    }

    // Define the table names based on the selected production stage
    $tableNames = [
        1 => '3dprinting',
        2 => 'pcbassembly',
        3 => 'monitorassembly',
        4 => 'predeploymentanalysis',
        5 => 'testing',
        6 => 'targets'
    ];

    // Check if the selected production stage exists in the tableNames array
    if (isset($tableNames[$productionStage])) {
        $tableName = $tableNames[$productionStage];
    } else {
        // Set a default table name if the selected production stage is invalid
        $tableName = 'targets';
    }

    // Handle form input values
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
    }
    else if (isset($_POST['batchNo'])) {
        $batchNo = $_POST['batchNo'];
    } 

    if (isset($_POST['datetime'])) {
        $datetime = $_POST['datetime'];
    } else {
        // Handle the error condition when datetime is not set
        echo "Error: Datetime is not set.";
        exit();
    }

    if (isset($_POST['qty'])) {
        $qty = $_POST['qty'];
    } else {
        // Handle the error condition when qty is not set
        echo "Error: Quantity is not set.";
        exit();
    }

    if (isset($_POST['status'])) {
        $status = $_POST['status'];
    } else {
        // Handle the error condition when eventdetail is not set
        echo "Error: Event Detail is not set.";
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO $tableName (batchNo, datetime, Qty, status) VALUES (?, ?, ?, ?)");
   // $stmt->bind_param("ssis", $batchNo, $datetime, $qty, $status);
    $execval = $stmt;

    if ($execval) {
        // Successful insertion, redirect to index.php
        header('Location: index.php');
        exit();
    } else {
        // Handle the error
      //  echo "Error: " . $stmt->error;
    }

   // $stmt->close();
    $conn->close();
}
?>
