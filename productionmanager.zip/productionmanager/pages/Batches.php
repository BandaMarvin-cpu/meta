<!DOCTYPE html>

<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Airqo Hardware Production</title>
  <!-- plugins:css -->
   <link rel="stylesheet" href="vendors/iconfonts/font-awesome/css/all.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">

  <link rel="stylesheet" href="css/x.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/logo.png" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <link rel="stylesheet" href="css/x.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&display=swap" rel="stylesheet">

    <script defer src="script.js"></script> 
</head>



<body>


  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row default-layout-navbar">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <img src="images/logo.png" width= "20%" boarder-radius="3cm" alt=" "/>
        <img src="images/mak_logo.png" width= "21%" boarder-radius="3cm" alt=" "/>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="fas fa-bars"></span>
        </button>
      

      

        
        <ul class="navbar-nav">
          <li class="nav-item nav-search d-none d-md-flex">
            <div class="nav-link">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="fas fa-search"></i>
                  </span>
                </div>
                <input type="text" class="form-control" placeholder=".." aria-label="Search">
              </div>
            </div>
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown d-none d-lg-flex">
            <div class="nav-link">
             
            </div>
            
               <div id="MyClockDisplay" class="clock" onload="showTime()"></div>

    
          </li>


          <li class="nav-item nav-settings d-none d-lg-block">
            <a class="nav-link" href="#">
              <i class="fas fa-ellipsis-h"></i>
            </a>
          </li>

          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              ll
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item">
                <i class="fas fa-cog text-primary"></i>
                Account settings
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item">
                <i class="fas fa-power-off text-primary"></i>
                Log Out
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="fas fa-bars"></span>
        </button>
      </div>
    </nav>

                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <a class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have 16 new notifications
                </p>
                <span class="badge badge-pill badge-warning float-right">View all</span>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="fas fa-wrench mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium">Settings</h6>
                  <p class="font-weight-light small-text">
                    procurement
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="far fa-envelope mx-0"></i>
                  </div>
                </div>
 
              </a>
            </div>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      <div class="theme-setting-wrapper">
        <div id="settings-trigger" style="margin-left: 0cm;"><i class="fas fa-fill-drip"></i></div>
        <div id="theme-settings" class="settings-panel">
          <i class="settings-close fa fa-times"></i>
          <p class="settings-heading">SIDEBAR SKINS</p>
          <div class="sidebar-bg-options selected" id="sidebar-light-theme"><div class="img-ss rounded-circle bg-light border mr-3"></div>Light</div>
          <div class="sidebar-bg-options" id="sidebar-dark-theme"><div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark</div>
          <p class="settings-heading mt-2">HEADER SKINS</p>
          <div class="color-tiles mx-0 px-4">
            <div class="tiles primary"></div>
            <div class="tiles success"></div>
            <div class="tiles warning"></div>
            <div class="tiles danger"></div>
            <div class="tiles info"></div>
            <div class="tiles dark"></div>
            <div class="tiles default"></div>
          </div>
        </div>
      </div>
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close fa fa-times"></i>
        <ul class="nav nav-tabs" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">TO DO LIST</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">deadlines</a>
          </li>
        </ul>
        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <form class="form w-100">
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task-todo">Add</button>
                </div>
              </form>
            </div>
            <div class="list-wrapper px-3">
              <ul class="d-flex flex-column-reverse todo-list">
                <li>
       
                  <i class="remove fa fa-times-circle"></i>
                </li>
  
 
              </ul>
            </div>
            <div class="events py-4 border-bottom px-3">
              <div class="wrapper d-flex mb-2">
                <i class="fa fa-times-circle text-primary mr-2"></i>
                <span>time of ordering, </span>
              </div>
              <p class="mb-0 font-weight-thin text-gray">Callibration Vs.. PreDeploymentAnalysis</p>
              <p class="text-gray mb-0">progress bar</p>
            </div>
          </div>
          <!-- To do section tab ends -->
          <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">
            <div class="d-flex align-items-center justify-content-between border-bottom">
              <p class="settings-heading border-top-0 mb-3 pl-3 pt-0 border-bottom-0 pb-0">action-time-planning</p>
              <small class="settings-heading border-top-0 mb-3 pt-0 border-bottom-0 pb-0 pr-3 font-weight-normal">See All</small>
            </div>

          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="profile-image">
                <img src="images/faces/spiderman2.jpg" alt="image"/>
              </div>
              <div class="profile-name">
                <p class="name">
                  Welcome  User
                </p>
                <p class="designation">
                  Embbeded Systems 
                </p>
              </div>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Home</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Targets.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Targets</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Batches.php">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Batches</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Reports.php">
              <i class="fa fa-puzzle-piece menu-icon"></i>
              <span class="menu-title">Reports</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#page-layouts" aria-expanded="false" aria-controls="page-layouts">
              <i class="fab fa-trello menu-icon"></i>
              <span class="menu-title">StockTake_Tool</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="page-layouts">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item d-none d-lg-block"> <a class="nav-link" href="devices.php">Devices</a></li>
                <li class="nav-item d-none d-lg-block"> <a class="nav-link" href="Stocktake.php">Lab Inventory</a></li>
                <li class="nav-item d-none d-lg-block"> <a class="nav-link" href="bom.php">BOM</a></li>
              </ul>
            </div>
          </li>
        

           <li class="nav-item">
            <a class="nav-link" href="pages/documentation.php">
              <i class="far fa-file-alt menu-icon"></i>
              <span class="menu-title">Documentation</span>
            </a>
           </li>

                      <li class="nav-item">
            <a class="nav-link" href="mylinks.php">
              <i class="far fa-file-alt menu-icon"></i>
              <span class="menu-title">links</span>
            </a>
           </li>
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
                
             </div>


             
               Routine Activity:

               <html>
          
 
              <div class="row grid-margin">
             <div class="col-4">
                  <div class="d-flex flex-column flex-md-row align-items-center justify-content-between">




                  <!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Flat &amp; Shiny Button (hover effect)</title>
  <style>


.button {
  text-decoration: none;
  text-transform: uppercase;
  font-family: "Exo 2", sans-serif;
  font-weight: 300;
  font-size: 30px;
  display: inline-block;
  position: relative;
  text-align: center;
  color: #00c7ec;
  border: 1px solid #00c7ec;
  border-radius: 5px;
  line-height: 3em;
  padding-left: 5em;
  padding-right: 5em;
  box-shadow: 0 0 0 0 transparent;
  -webkit-transition: all 0.2s ease-in;
  -moz-transition: all 0.2s ease-in;
  transition: all 0.2s ease-in;
}
.button:hover {
  color: white;
  box-shadow: 0 0 30px 0 rgba(0, 199, 236, 0.5);
  background-color: #00c7ec;
  -webkit-transition: all 0.2s ease-out;
  -moz-transition: all 0.2s ease-out;
  transition: all 0.2s ease-out;
}
.button:hover:before {
  -webkit-animation: shine 0.5s 0s linear;
  -moz-animation: shine 0.5s 0s linear;
  animation: shine 0.5s 0s linear;
}
.button:active {
  box-shadow: 0 0 0 0 transparent;
  -webkit-transition: box-shadow 0.2s ease-in;
  -moz-transition: box-shadow 0.2s ease-in;
  transition: box-shadow 0.2s ease-in;
}
.button:before {
  content: "";
  display: block;
  width: 0px;
  height: 86%;
  position: absolute;
  top: 7%;
  left: 0%;
  opacity: 0;
  background: white;
  box-shadow: 0 0 15px 3px white;
  -webkit-transform: skewX(-20deg);
  -moz-transform: skewX(-20deg);
  -ms-transform: skewX(-20deg);
  -o-transform: skewX(-20deg);
  transform: skewX(-20deg);
}

@-webkit-keyframes shine {
  from {
    opacity: 0;
    left: 0%;
  }
  50% {
    opacity: 1;
  }
  to {
    opacity: 0;
    left: 100%;
  }
}
@-moz-keyframes shine {
  from {
    opacity: 0;
    left: 0%;
  }
  50% {
    opacity: 1;
  }
  to {
    opacity: 0;
    left: 100%;
  }
}
@keyframes shine {
  from {
    opacity: 0;
    left: 0%;
  }
  50% {
    opacity: 1;
  }
  to {
    opacity: 0;
    left: 100%;
  }
}

  </style>

</head>
<body>
<!-- partial:index.partial.html -->
<a href="#" class="button">Ooh, shiny!</a>
<!-- partial -->
  
</body>
</html>






          <div class="col-lg-4 grid-margin stretch-card">
           

             
          </div>
          <!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Pure CSS Featured Image Slider</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
<style>/* Images from Craig Henry's Dribbble profile: http://dribbble.com/craighenry */


    * {
        margin: 0;
        padding: 0;
    }
     {
        background-color: #eefbf8;
        background-image: radial-gradient(circle, hsla(0,0%,100%,.1), hsla(0,0%,0%,.75)),
                          linear-gradient(left, transparent 50%, hsla(0,0%,0%,.01) 50%);
        
        background-repeat: no-repeat, repeat;
        background-size: 150% 150%, 3em 3em;
        font-size: 50%;
        min-height: 50%;
    }
      /**********/
     /* Slider */
    /**********/
    
    .slider {
        background-color: #fff;
        box-shadow: inset 0 0 2px hsla(0,0%,0%,.2),
                    0 3px 1px hsla(0,0%,100%,.75),
                    0 -1px 1px 2px hsla(0,0%,0%,.1);
        height: 18.75em;
        left: 50%;
        margin: -9.875em -13em;
        padding: .5em;
     
        top: 50%;
        width: 25em;
    }
    
    /* Frame */
    
    .slider:before {
        background-color: #22130c;
        bottom: -2.5em;
        box-shadow: inset 0 1px 1px 1px hsla(0,0%,100%,.2),
                    inset 0 -2px 1px hsla(0,0%,0%,.4),
                    0 5px 50px hsla(0,0%,0%,.25),
                    0 20px 20px -15px hsla(0,0%,0%,.2),
                    0 30px 20px -15px hsla(0,0%,0%,.15),
                    0 40px 20px -15px hsla(0,0%,0%,.1);
        content: '';
        left: -2.5em;
        position: absolute;
        right: -2.5em;
        top: -2.5em;
        z-index: -1;
    }
    
    /* Mat */
    
    .slider:after {
        background-color: #fff5e5;
        bottom: -1.5em;
        box-shadow: 0 2px 1px hsla(0,0%,100%,.2),
                    0 -1px 1px 1px hsla(0,0%,0%,.4),
                    inset 0 2px 3px 1px hsla(0,0%,0%,.2),
                    inset 0 4px 3px 1px hsla(0,0%,0%,.2),
                    inset 0 6px 3px 1px hsla(0,0%,0%,.1);
        content: '';
        left: -1.5em;
        position: absolute;
        right: -1.5em;
        top: -1.5em;
        z-index: -1;
    }
    
    /* Slides */
    
    .slider li {
        box-shadow: 0 -1px 0 2px hsla(0,0%,0%,.03);
        list-style:none;
        position: absolute;
    }
    .slider input {
        display: none;
    }
    
    /* Navigation */
    
    .slider label {
        background-color: #111;
        background-image: linear-gradient(transparent, hsla(0,0%,0%,.25));
        border: .2em solid transparent;
        bottom: .5em;
        border-radius: 100%;
        cursor: pointer;
        display: block;
        height: .5em;
        left: 24em;
        opacity: 0;
        position: absolute;
        transition: .25s;
        width: .5em;
        visibility: hidden;
        z-index: 10;
    }
    .slider label:after {
        border-radius: 100%;
        bottom: -.2em;
        box-shadow: inset 0 0 0 .2em #111,
                    inset 0 2px 2px #000,
                    0 1px 1px hsla(0,0%,100%,.25);
        content: '';
        left: -.2em;
        position: absolute;
        right: -.2em;
        top: -.2em;
    }
    .slider:hover label {
        opacity: 1;
        visibility: visible;
    }
    .slider input:checked + label {
        background-color: #fff;
    }
    .slider:hover li:nth-child(1) label {
        left: .5em;
    }
    .slider:hover li:nth-child(2) label {
        left: 2em;
    }
    .slider:hover li:nth-child(3) label {
        left: 3.5em;
    }
    .slider:hover li:nth-child(4) label {
        left: 5em;
    }
    
    /* Images */
    
    .slider img {
        height: 18.75em;
        opacity: 0;
        transition: .25s;
        width: 25em;
        vertical-align: top;
        visibility: hidden;
    }
    .slider li input:checked ~ img {
        opacity: 1;
        visibility: visible;
        z-index: 10;
    }</style>
</head>
<body>
<!-- partial:index.partial.html -->
<!-- Images from Craig Henry's Dribbble profile: http://dribbble.com/craighenry -->
<br><br>
<ul class="slider">
  
    <li> 
        <input type="radio" id="slide1" name="slide" checked>
        <label for="slide1"></label>
        <img src="https://dribbble.s3.amazonaws.com/users/322/screenshots/872485/coldchase.jpg" alt="Panel 1">
    </li>
    <li>
        <input type="radio" id="slide2" name="slide">
        <label for="slide2"></label>
        <img src="https://dribbble.s3.amazonaws.com/users/322/screenshots/980517/icehut_sm.jpg" alt="Panel 2">
    </li>
    <li>
        <input type="radio" id="slide3" name="slide">
        <label for="slide3"></label>
        <img src="https://dribbble.s3.amazonaws.com/users/322/screenshots/943660/hq_sm.jpg" alt="Panel 3">
    </li>
    <li>
        <input type="radio" id="slide4" name="slide">
        <label for="slide4"></label>
        <img src="https://dribbble.s3.amazonaws.com/users/322/screenshots/599584/home.jpg" alt="Panel 4">
    </li>
</ul>
<!-- partial -->
  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
</body>
</html>

     

<script>
  function showConfirmation() {
    if (confirm('Are you sure you want to submit the form?')) {
      // Code to submit the form
      // You can add your form submission logic here
    }
  }

  function closeForm() {
    // Code to close the form or perform any other necessary actions
  }
</script>

                 </form>



                </div>





                <div id="bot">
  <div id="container">
    <div id="header">
        Online Chatbot App
    </div>

    <div id="body">
        <!-- This section will be dynamically inserted from JavaScript -->
        <div class="userSection">
          <div class="messages user-message">

          </div>
          <div class="seperator"></div>
        </div>
        <div class="botSection">
          <div class="messages bot-reply">

          </div>
          <div class="seperator"></div>
        </div>                
    </div>

    <div id="inputArea">
      <input type="text" name="messages" id="userInput" placeholder="Please enter your message here" required>
      <input type="submit" id="send" value="Send">
    </div>
  </div>
  </div>

  <script type="text/javascript">

// When send button gets clicked
document.querySelector("#send").addEventListener("click", async () => {

  // create new request object. get user message
  let xhr = new XMLHttpRequest();
  var userMessage = document.querySelector("#userInput").value


  // create html to hold user message. 
  let userHtml = '<div class="userSection">'+'<div class="messages user-message">'+userMessage+'</div>'+
  '<div class="seperator"></div>'+'</div>'


  // insert user message into the page
  document.querySelector('#body').innerHTML+= userHtml;

  // open a post request to server script. pass user message as parameter 
  xhr.open("POST", "query.php");
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.send(`messageValue=${userMessage}`);


  // When response is returned, get reply text into HTML and insert in page
  xhr.onload = function () {
      let botHtml = '<div class="botSection">'+'<div class="messages bot-reply">'+this.responseText+'</div>'+
      '<div class="seperator"></div>'+'</div>'

      document.querySelector('#body').innerHTML+= botHtml;
  }

})

</script>





</html>  



<footer class="footer">  
          hjgkjhg          
                  </footer>

    <script src="/script.js"></script>
  <!-- container-scroller -->
  <script>
    function openForm() {
      document.getElementById("myForm").style.display = "block";
    }


    function openpcbForm() {
      document.getElementById("myForm").style.display = "block";
    }
    
    function closeForm() {
      document.getElementById("myForm").style.display = "none";
    }
    </script>
  <!-- plugins:js -->
  <script>function showTime(){
    var date = new Date();
    var h = date.getHours(); // 0 - 23
    var m = date.getMinutes(); // 0 - 59
    var s = date.getSeconds(); // 0 - 59
    var session = "AM";
    
    if(h == 0){
        h = 12;
    }
    
    if(h > 12){
        h = h - 12;
        session = "PM";
    }
    
    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;
    
    var time = h + ":" + m + ":" + s + " " + session;
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;
    
    setTimeout(showTime, 1000);
    
}

showTime();</script>
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/chart.js"></script>
  <script src="js/progress.js"></script>
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <script src="js/3d.js"></script>
  <script defer src="js/xylo.js"></script> 
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
  <script  src="./script.js"></script>

  
</body>

</html>







