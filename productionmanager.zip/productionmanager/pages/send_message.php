<?php
// Establish connection to your MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airqo1";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $message = $_POST['message'];

  // Prepare and execute the SQL statement to insert the message
  $stmt = $conn->prepare("INSERT INTO chat_messages (sender, message) VALUES (?, ?)");
  $stmt->bind_param("ss", $sender, $message);
  $sender = "User";
  $stmt->execute();
  $stmt->close();
}

$conn->close();
?>
