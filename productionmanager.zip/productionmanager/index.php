<?php session_start(); ?>
<html>
<head>
	<title>Homepage</title>
	<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
	<div id="header">
		Welcome to my page!
	</div>
	<?php
	if(isset($_SESSION['valid'])) {			
		include("connection.php");					
		$result = mysqli_query($mysqli, "SELECT * FROM login");
	?>
				
		Welcome <?php echo $_SESSION['name'] ?> ! <a href='logout.php'>Logout</a><br/>
		<br/>
		<a href='view.php'>View and Add Products</a>
		<br/><br/>
	<?php	
	} else {
		echo "You must be logged in to view this page.<br/><br/>";
		echo "<a href='login.php'>Login</a> | <a href='register.php'>Register</a>";
	}
	?>
	<div id="footer">
		Created by <a href="http://blog.chapagain.com.np" title="Mukesh Chapagain">Mukesh Chapagain</a>
	</div>
</body>
</html>


<head>
  <meta charset="UTF-8">
  <title>Hardware Production</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'><link rel="stylesheet" href="style.css">
<style>
	.main-content{
	width: 50%;
	border-radius: 20px;
	box-shadow: 0 5px 5px rgba(0,0,0,.4);
	margin: 5em auto;
	display: flex;
}
.company__info{
	background-color: #008080;
	border-top-left-radius: 20px;
	border-bottom-left-radius: 20px;
	display: flex;
	flex-direction: column;
	justify-content: center;
	color: #fff;
}
.fa-android{
	font-size:3em;
}
@media screen and (max-width: 640px) {
	.main-content{width: 90%;}
	.company__info{
		display: none;
	}
	.login_form{
		border-top-left-radius:20px;
		border-bottom-left-radius:20px;
	}
}
@media screen and (min-width: 642px) and (max-width:800px){
	.main-content{width: 70%;}
}
.row > h2{
	color:#008080;
}
.login_form{
	background-color: #fff;
	border-top-right-radius:20px;
	border-bottom-right-radius:20px;
	border-top:1px solid #ccc;
	border-right:1px solid #ccc;
}
form{
	padding: 0 2em;
}
.form__input{
	width: 100%;
	border:0px solid transparent;
	border-radius: 0;
	border-bottom: 1px solid #aaa;
	padding: 1em .5em .5em;
	padding-left: 2em;
	outline:none;
	margin:1.5em auto;
	transition: all .5s ease;
}
.form__input:focus{
	border-bottom-color: #008080;
	box-shadow: 0 0 5px rgba(0,80,80,.4); 
	border-radius: 4px;
}
.btn{
	transition: all .5s ease;
	width: 70%;
	border-radius: 30px;
	color:#008080;
	font-weight: 600;
	background-color: #fff;
	border: 1px solid #008080;
	margin-top: 1.5em;
	margin-bottom: 1em;
}
.btn:hover, .btn:focus{
	background-color: #008080;
	color:#fff;
}
</style>
</head>
<body>
<!-- partial:index.partial.html -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Yinka Enoch Adedokun">
	<title>Login Page</title>
</head>
<body>
	<!-- Main Content -->
	<div class="container-fluid">
		<div class="row main-content bg-success text-center">
			<div class="col-md-4 text-center company__info">
				<span class="company__logo"><h2><span class="fa fa-android"></span></h2></span>
				<h4 class="company_title">Airqo Hardware
				</h4>
			</div>

			<!DOCTYPE html>
			<html>
			<head>
				<title>Login Form</title>
			</head>
			<body>
				<div class="col-md-8 col-xs-12 col-sm-12 login_form">
					<div class="container-fluid">
						<div class="row">
							<h2>Log In</h2>
						</div>
						<div class="row">
							<form control="" class="form-group" action="../pages/index.php" method="POST">
								<div class="row">
									<input type="text" name="username" id="username" class="form__input" placeholder="Username">
								</div>
								<div class="row">
									<input type="password" name="password" id="password" class="form__input" placeholder="Password">
								</div>
								<div class="row">
									<input type="checkbox" name="remember_me" id="remember_me">
									<label for="remember_me">Remember Me!</label>
								</div>
								<div class="row">
									<input type="submit" value="Submit" class="btn">
								</div>
							</form>
						</div>
						<div class="row">
							<p>Don't have an account? <a href="#">Register Here</a></p>
						</div>
					</div>
				</div>
			</body>
			</html>
			

		</div>
	</div>
	<!-- Footer -->
	<div class="container-fluid text-center footer">
		Coded with &hearts; by <a href="https://www.google/bandamarvin">marv</a></p>
	</div>
</body>
<!-- partial -->
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Rubiks cube wireframe</title>
<style>
body, html{
	margin: 0;
	padding: 0;
	width: 100%;
	height: 100%;
	text-align: center;
	background: #111;
}

#canvas
{
  background: #111;
  height: 400px;
  width: 400px;
	
	margin: 0 auto;
	padding: 0;
	
	position: relative;
  top: 50%;
  transform: translateY(-50%);
}

</style>

</head>
<body>
<!-- partial:index.partial.html -->
<html>
  <head>
    <meta charset="UTF-8">
    <title>Rubik's cube wireframe</title>
  </head>
  <body>
    <canvas id="canvas">
      Sorry, canvas features are not supported by your browser.
    </canvas>
  </body>
</html>
<!-- partial -->
  <script>

var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var height = canvas.height = 400;
var width = canvas.width = 400;
var fov = Math.PI/2;
var fovVertical = fov;
var fovHorizontal = 2 * Math.atan(height*Math.tan(fov/2)/width);
var worldTransform = {x:0,y:0,z:4,rotX:0,rotY:0,rotZ:0};
//Animation Variables
var slice = 0;
var rotationType = 0;
var rotationAmount = 0;
var animationTimer = 0;
//Constants (Change it if you want)
var animationDuration = 70;
var blur = 0; //from 0 to 1
//Easing function from:
//http://gizma.com/easing/
Math.easeOutExpo = function (t, b, c, d) {
	return c * ( -Math.pow( 2, -10 * t/d ) + 1 ) + b;
};

var Point = function(x, y, z){
  this.x = x;
  this.y = y;
  this.z = z;
};
Point.prototype.project = function(){
  return new Point(
	  width*(this.x/(this.z*2*Math.tan(fovVertical/2)) + 1/2),
	  height*(this.y/(this.z*2*Math.tan(fovHorizontal/2)) + 1/2)
  );
};
Point.prototype.rotateX = function(theta){
  return new Point(
    this.x,
	  this.y * Math.cos(theta) - this.z * Math.sin(theta),
	  this.y * Math.sin(theta) + this.z * Math.cos(theta)
	);
};
Point.prototype.rotateY = function(theta){
  return new Point(
	  this.x * Math.cos(theta) - this.z * Math.sin(theta),
	  this.y,
	  this.x * Math.sin(theta) + this.z * Math.cos(theta)
	);
};
Point.prototype.rotateZ = function(theta){
  return new Point(
	  this.x * Math.cos(theta) - this.y * Math.sin(theta),
	  this.x * Math.sin(theta) + this.y * Math.cos(theta),
	  this.z
	);
};
Point.prototype.translate = function(x, y, z){
  return new Point(
    this.x + x,
    this.y + y,
    this.z + z
  );
};

var cubeLines = [[0,1],[0,2],[0,4],[1,3],[1,5],[2,3],[2,6],[3,7],[4,5],[4,6],[5,7],[6,7]];
var slices = [[0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 ],
              [9 , 10, 11, 12, 13, 14, 15, 16, 17],
              [18, 19, 20, 21, 22, 23, 24, 25, 26],
              [0 , 1 , 2 , 9 , 10, 11, 18, 19, 20],
              [3 , 4 , 5 , 12, 13, 14, 21, 22, 23],
              [6 , 7 , 8 , 15, 16, 17, 24, 25, 26],
              [0 , 3 , 6 , 9 , 12, 15, 18, 21, 24],
              [1 , 4 , 7 , 10, 13, 16, 19, 22, 25],
              [2 , 5 , 8 , 11, 14, 17, 20, 23, 26]];
var sliceRotations = [[],[],[],[],[],[],[],[],[]];
var Cube = function(xpos, ypos, zpos, xrot, yrot, zrot){
  this.x = xpos;
  this.y = ypos;
  this.z = zpos;
  
  this.rotX = xrot;
  this.rotY = yrot;
  this.rotZ = zrot;
	
  this.points = [];
  this.projected = [];
  for(var x = -0.5;x <= 0.5;x++)
    for(var y = -0.5;y <= 0.5;y++)
      for(var z = -0.5;z <= 0.5;z++)
        this.points.push(new Point(x, y, z));
};
Cube.prototype.project = function(){
  for(var x = 0;x < 8;x++)
    this.projected[x] = this.points[x].translate(this.x, this.y, this.z).rotateX(this.rotX).rotateY(this.rotY).rotateZ(this.rotZ).rotateX(worldTransform.rotX).rotateY(worldTransform.rotY).rotateZ(worldTransform.rotZ).translate(worldTransform.x, worldTransform.y, worldTransform.z).project();
};
Cube.prototype.draw = function(){
  ctx.strokeStyle = "#fff";
  this.project();
  
  for(var x = 0;x < 12;x++){
    ctx.beginPath();
    ctx.moveTo(this.projected[cubeLines[x][0]].x, this.projected[cubeLines[x][0]].y);
    ctx.lineTo(this.projected[cubeLines[x][1]].x, this.projected[cubeLines[x][1]].y);
    ctx.stroke();
  }
};

var cubes = [];
for(var x = -1;x <= 1;x++)
  for(var y = -1;y <= 1;y++)
    for(var z = -1;z <= 1;z++)
      cubes.push(new Cube(x, y, z, 0, 0, 0));

var startAnimation = function(){
  slice = parseInt(Math.random() * 9);
  rotationType = parseInt(slice / 3);
  rotationAmount = Math.PI * (parseInt(Math.random() * 2) + 1) / 2;
  rotationAmount = Math.random() * 2 > 1 ? rotationAmount : -rotationAmount;
  animationTimer = animationDuration;
};

var updateAnimation = function()
{
  var currentRotation = Math.easeOutExpo(animationDuration - animationTimer, 0, rotationAmount, animationDuration);
  
  for(var x = 0;x < 9;x++)
  {
    if(rotationType === 0)
      cubes[slices[slice][x]].rotX = currentRotation;
    if(rotationType == 1)
      cubes[slices[slice][x]].rotY = currentRotation;
    if(rotationType == 2)
      cubes[slices[slice][x]].rotZ = currentRotation;
  }
};

var resetRotation = function()
{
  for(var x = 0;x < 27;x++)
  {
    cubes[x].rotX = 0;
    cubes[x].rotY = 0;
    cubes[x].rotZ = 0;
  }
};

startAnimation();
updateAnimation();

var draw = function(){ 
  ctx.fillStyle = "rgba(17, 17, 17,"+ (1 - blur) +")";
  ctx.fillRect(0, 0, width, height);
  
  worldTransform.rotX += 0.002;
  worldTransform.rotY += 0.001;
  
  for(var x = 0;x < 27;x++){
    cubes[x].draw();  
  }
  
  if(animationTimer > 0)
  {
    animationTimer--;
    updateAnimation();
  }
  else
  {
    resetRotation();  
    startAnimation();
  }
  requestAnimationFrame(draw);
};
requestAnimationFrame(draw);
  </script>

</body>
</html>

</body>
</html>
